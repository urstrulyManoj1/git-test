from django.db import models

# Create your models here.
# In your Django app's models.py file
class Item(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name